# Ketu Patel — Portfolio source code

## Publish the public portfolio on GitHub Pages

1. Extract this ZIP. Upload its contents (including `docs` and `full-source`) to a GitHub repository. Do not upload only the ZIP.
2. Open repository **Settings → Pages**.
3. Choose **Deploy from a branch**, branch **main**, folder **/docs**, then Save.
4. GitHub will display your live website address after deployment.

`docs/` is the standalone public portfolio. It contains the current public project records and their uploaded images exported from your live site, plus your portrait, design, contact form and WhatsApp links. It works at both a repository subpath and a custom domain. Preview with `python -m http.server 8000` from this directory, then open http://localhost:8000/docs/.

To update this static version, edit the HTML/CSS or `docs/portfolio-data.json` and add images/videos under `docs/assets/`. Commit your changes; Pages publishes them. Images can use 1080×1350 and reels 9:16. Remove a record from JSON to remove a project. Keep record IDs unique. `images` is an ordered array of asset paths; `media` is the cover image or reel video. All files in a public repository are publicly readable.

## Complete original application

`full-source/` contains the complete tracked application source, dependency lockfile, tests, owner editor, upload/gallery/delete implementation and original assets. Dependencies and generated build output are intentionally omitted. No account credentials are included.

The original application relies on ChatGPT Sites authentication and a Cloudflare R2 bucket (`BUCKET`), with `PORTFOLIO_OWNER_EMAIL` configured as a server secret. It is NOT a standalone GitHub Pages backend. The owner management button is absent from the static public version. GitHub Pages does not run server APIs, authenticated editing or uploads.

To retain the online owner editor on another host, a developer must configure a server runtime and persistent storage, replace Sites authentication with independently verified login, migrate the records/media and configure the owner restriction. Never trust client-supplied identity headers on an unprotected server. Simply deploying the original source outside Sites does not supply authentication.

The live data export is in `docs/portfolio-data.json` and `docs/assets/exported/`. Original source seed data is historical, and does not represent current deletions or edits. Deleted records and private server state are not exported.

For original-source development use Node >=22.13.0, the pinned pnpm version in package.json, install dependencies, and run the supplied build scripts in an environment with the required platform bindings. `node tests/portfolio.cjs` exercises backend logic with mocked bindings.

WhatsApp opens a prefilled message; visitors still press Send in WhatsApp.

GitHub documentation: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

## Compact download
Images in this package are resized to at most 1350 pixels per side and compressed for a download under 25 MB. Source code and all project images are included. Keep your original image files separately if you need full-resolution originals.
