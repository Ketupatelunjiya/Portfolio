document.querySelectorAll('[data-filter]').forEach(button=>button.addEventListener('click',()=>{document.querySelectorAll('[data-filter]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));document.querySelectorAll('.project').forEach(p=>p.hidden=button.dataset.filter!=='all'&&p.dataset.category!==button.dataset.filter)}));
const dialog=document.querySelector('dialog:not(#call-dialog)');
if(dialog){document.querySelectorAll('[data-project]').forEach(b=>b.addEventListener('click',()=>{document.getElementById('dialog-content').innerHTML=document.getElementById(b.dataset.project).innerHTML;dialog.showModal()}));dialog.querySelector('.close').addEventListener('click',()=>dialog.close());dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close()}})}
const form=document.getElementById('brief');
if(form){form.addEventListener('submit',e=>{
 e.preventDefault();
 const name=form.elements.name, details=form.elements.details;
 [name,details].forEach(field=>field.setCustomValidity(field.value.trim()?'':'Please fill in this field.'));
 if(!form.reportValidity())return;
 const d=new FormData(form);
 const message=`Hi Ketu! I’m ${d.get('name').trim()}.\n\nProject: ${d.get('type')}\n\n${d.get('details').trim()}\n\nI’d like to discuss this project with you.`;
 const url='https://wa.me/917778004027?text='+encodeURIComponent(message);
 document.getElementById('whatsapp-enquiry').href=url;
 document.getElementById('brief-result').hidden=false;
 window.open(url,'_blank','noopener,noreferrer');
});
 form.addEventListener('input',e=>{if(e.target.setCustomValidity)e.target.setCustomValidity('')});
}

const callDialog=document.getElementById('call-dialog');if(callDialog){document.querySelectorAll('[data-call]').forEach(b=>b.addEventListener('click',()=>callDialog.showModal()));callDialog.querySelector('.close').addEventListener('click',()=>callDialog.close());callDialog.addEventListener('click',e=>{if(e.target===callDialog){const r=callDialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)callDialog.close()}})}
