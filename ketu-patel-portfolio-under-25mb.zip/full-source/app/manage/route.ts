import html from '../../lib/manager-html';
import {owner} from '../../lib/portfolio-server';
export const dynamic='force-dynamic';
export function GET(request:Request){if(!request.headers.get('oai-authenticated-user-id'))return Response.redirect(new URL('/signin-with-chatgpt?return_to=%2Fmanage',request.url));if(!owner(request))return new Response('This editor is only available to the portfolio owner.',{status:403});return new Response(html,{headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'}})}
