import {api} from '../../../../lib/portfolio-server';
export const dynamic='force-dynamic';
export const GET=api;export const POST=api;
