import { env } from 'cloudflare:workers';
import seeds from './portfolio-seed.json';
const json=(body:any,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'no-store'}});
export function owner(request:Request){return !!request.headers.get('oai-authenticated-user-id') && !!(env as any).PORTFOLIO_OWNER_EMAIL && request.headers.get('oai-authenticated-user-email')?.toLowerCase()===(env as any).PORTFOLIO_OWNER_EMAIL.toLowerCase()}
const bucket=()=> (env as any).BUCKET as R2Bucket;
async function records(){let list:any[]=[...seeds];let cursor:string|undefined;do{const page=await bucket().list({prefix:'portfolio/records/',cursor});const values=await Promise.all(page.objects.map(async o=>{const v=await bucket().get(o.key);return v?{...await v.json<any>(),revision:v.etag}:null}));for(const v of values.filter(Boolean)){list=list.filter(x=>x.id!==v.id);list.push(v)}cursor=page.truncated?page.cursor:undefined}while(cursor);return list.filter(x=>!x.deleted)}
export async function api(request:Request){
 const path=new URL(request.url).pathname.replace('/api/portfolio','');
 if(path==='/session')return json({owner:owner(request)});
 if(request.method==='GET'&&path==='/entries')return json(await records());
 if(request.method==='GET'&&path.startsWith('/media/')){
  const key=path.slice(7);if(!/^[a-f0-9-]+\.(png|jpg|webp|mp4|webm)$/.test(key))return new Response('Not found',{status:404});
  const file=await bucket().get('portfolio/media/'+key,{range:request.headers});if(!file)return new Response('Not found',{status:404});
  const headers=new Headers({'Cache-Control':'public, max-age=31536000, immutable','Accept-Ranges':'bytes','X-Content-Type-Options':'nosniff'});file.writeHttpMetadata(headers);headers.set('ETag',file.httpEtag);
  let status=200;const range=file.range;if(range&&'offset'in range&&range.length!==undefined){status=206;headers.set('Content-Range',`bytes ${range.offset}-${range.offset+range.length-1}/${file.size}`);headers.set('Content-Length',String(range.length))}else headers.set('Content-Length',String(file.size));return new Response(file.body,{status,headers});
 }
 if(!owner(request))return json({error:'Owner access required.'},403);
 if(request.method!=='POST')return json({error:'Not found'},404);
 if(request.headers.get('Origin')!==new URL(request.url).origin)return json({error:'Invalid request origin.'},403);
 if(path==='/upload'){
  if(Number(request.headers.get('Content-Length'))>50*1024*1024)return json({error:'Maximum upload size is 50 MB.'},413);
  const type=request.headers.get('Content-Type')||'';const ext:Record<string,string>={'image/png':'png','image/jpeg':'jpg','image/webp':'webp','video/mp4':'mp4','video/webm':'webm'};
  if(!ext[type])return json({error:'Use PNG, JPG, WebP, MP4 or WebM.'},400);
  const bytes=await request.arrayBuffer();if(bytes.byteLength>50*1024*1024||!bytes.byteLength)return json({error:'Upload must be between 1 byte and 50 MB.'},413);
  const name=crypto.randomUUID()+'.'+ext[type];await bucket().put('portfolio/media/'+name,bytes,{httpMetadata:{contentType:type}});return json({url:'/api/portfolio/media/'+name});
 }
 if(path==='/delete'||path==='/restore'){
  let d:any;try{d=await request.json()}catch{return json({error:'Invalid request'},400)}
  if(typeof d.id!=='string'||!/^[a-z0-9-]{1,90}$/.test(d.id))return json({error:'Invalid project'},400);
  const key='portfolio/records/'+d.id+'.json',old=await bucket().get(key);
  const value=old?await old.json<any>():seeds.find(x=>x.id===d.id);
  if(!value)return json({error:'Project not found'},404);
  if(d.revision!==(old?old.etag:'seed'))return json({error:'This project changed in another tab. Reload before trying again.'},409);
  const record={...value,deleted:path==='/delete',updatedAt:new Date().toISOString()};delete record.revision;
  const saved=await bucket().put(key,JSON.stringify(record),{onlyIf:old?{etagMatches:old.etag}:{etagDoesNotMatch:'*'},httpMetadata:{contentType:'application/json'}});
  if(!saved)return json({error:'This project changed. Reload before trying again.'},409);
  return json({...record,revision:saved.etag});
 }
 if(path==='/save'){
  if(Number(request.headers.get('Content-Length'))>30000)return json({error:'Entry too long'},413);
  let d:any;try{d=await request.json()}catch{return json({error:'Invalid entry'},400)}
  if(!['work','clients'].includes(d.section)||!['post','reel'].includes(d.kind)||typeof d.title!=='string'||!d.title.trim()||d.title.length>150||typeof d.description!=='string'||d.description.length>10000)return json({error:'Please provide a title and valid project details.'},400);
  const safeMedia=(x:any)=>typeof x==='string'&&(x===''||/^\/assets\/[\w.-]+$/.test(x)||/^\/api\/portfolio\/media\/[a-f0-9-]+\.(png|jpg|webp|mp4|webm)$/.test(x));
  const images=d.images===undefined?(d.kind==='post'&&d.media?[d.media]:[]):d.images;
  if(!Array.isArray(images)||images.length>20||images.some((x:any)=>!safeMedia(x)||!x||!/\.(png|jpg|webp)$/.test(x))||(d.kind==='reel'&&images.length))return json({error:'Use up to 20 valid images for a post.'},400);
  if(d.kind==='post')d.media=images[0]||'';
  if(!safeMedia(d.media)||!safeMedia(d.logo))return json({error:'Invalid media'},400);
  const isSeed=seeds.some(x=>x.id===d.id);const id=d.id||crypto.randomUUID();if(!/^[a-z0-9-]{1,90}$/.test(id))return json({error:'Invalid entry'},400);
  const key='portfolio/records/'+id+'.json',old=await bucket().get(key);
  if(old&&(await old.json<any>()).deleted)return json({error:'This project was deleted. Restore it before editing.'},409);
  if(old&&d.revision!==old.etag)return json({error:'This entry changed in another tab. Reload it before saving.'},409);
  if(!old&&d.id&&!isSeed)return json({error:'Entry not found'},404);
  if(!d.media&&!isSeed)return json({error:'Upload an image or reel before saving.'},400);
  if(d.kind==='reel'&&!/\.(mp4|webm)$/.test(d.media))return json({error:'A reel needs an MP4 or WebM video.'},400);
  if(d.kind==='post'&&d.media&&!/\.(png|jpg|webp)$/.test(d.media))return json({error:'A post needs an image.'},400);
  const value={id,section:d.section,title:d.title.trim(),subtitle:String(d.subtitle||'').slice(0,250),category:['identity','digital','graphic'].includes(d.category)?d.category:'graphic',description:d.description.trim(),kind:d.kind,media:d.media,images,logo:d.logo,legacy:seeds.find(x=>x.id===id)?.legacy||'',updatedAt:new Date().toISOString()};
  const saved=await bucket().put(key,JSON.stringify(value),{onlyIf:old?{etagMatches:old.etag}:{etagDoesNotMatch:'*'},httpMetadata:{contentType:'application/json'}});if(!saved)return json({error:'Another save just completed. Reload this entry.'},409);
  return json({...value,revision:saved.etag});
 }
 return json({error:'Not found'},404);
}
