const ts=require('typescript'),fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
let serial=0;const objects=new Map();const BUCKET={async list(){return {objects:[...objects.keys()].filter(k=>k.startsWith('portfolio/records/')).map(key=>({key})),truncated:false}},async get(key){const o=objects.get(key);return o?{etag:o.etag,json:async()=>JSON.parse(o.value)}:null},async put(key,value,options){const old=objects.get(key);if(options?.onlyIf?.etagMatches&&old?.etag!==options.onlyIf.etagMatches)return null;if(options?.onlyIf?.etagDoesNotMatch==='*'&&old)return null;const etag='v'+(++serial);objects.set(key,{value,etag});return {etag}}};
const moduleMock={exports:{}};const js=ts.transpileModule(fs.readFileSync('lib/portfolio-server.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,esModuleInterop:true}}).outputText;
vm.runInNewContext(js,{module:moduleMock,exports:moduleMock.exports,require(name){if(name==='cloudflare:workers')return {env:{PORTFOLIO_OWNER_EMAIL:'owner@example.test',BUCKET}};if(name==='./portfolio-seed.json')return JSON.parse(fs.readFileSync('lib/portfolio-seed.json'));throw Error(name)},Response,Request,Headers,URL,crypto:require('node:crypto').webcrypto});const {api}=moduleMock.exports;
function req(path,{as='owner',body,origin='https://portfolio.test',method=body?'POST':'GET',type='application/json'}={}){return new Request('https://portfolio.test/api/portfolio'+path,{method,headers:{...(as?{'oai-authenticated-user-id':'test-user','oai-authenticated-user-email':as==='owner'?'owner@example.test':'visitor@example.test'}:{}),Origin:origin,'Content-Type':type},body:body?(typeof body==='string'?body:JSON.stringify(body)):undefined})}
(async()=>{assert.equal((await (await api(req('/session',{as:null}))).json()).owner,false);assert.equal((await (await api(req('/session',{as:'visitor'}))).json()).owner,false);assert.equal((await (await api(req('/session'))).json()).owner,true);
const data={section:'work',title:'Example <script>',description:'Project description',subtitle:'Test',category:'digital',kind:'post',media:'/assets/active-work.png',logo:''};
for(const as of [null,'visitor'])assert.equal((await api(req('/save',{as,body:data}))).status,403);
assert.equal((await api(req('/save',{origin:'https://evil.test',body:data}))).status,403);
assert.equal((await api(req('/save',{body:{...data,media:'javascript:alert(1)'}}))).status,400);
assert.equal((await api(req('/save',{body:{...data,kind:'reel'}}))).status,400);
const saved=await (await api(req('/save',{body:data}))).json();assert(saved.id);let list=await (await api(req('/entries',{as:null}))).json();assert(list.some(x=>x.id===saved.id));
const edit=await (await api(req('/save',{body:{...saved,title:'Edited'}}))).json();assert.equal(edit.title,'Edited');assert.equal((await api(req('/save',{body:saved}))).status,409);
const seed=list.find(x=>x.id==='client-active-car-care');const s=await (await api(req('/save',{body:{...seed,title:'Updated client'}}))).json();assert.equal(s.title,'Updated client');assert.equal(s.section,'clients');
assert.equal((await api(req('/upload',{as:'visitor',body:'image',type:'image/png'}))).status,403);assert.equal((await api(req('/upload',{body:'svg',type:'image/svg+xml'}))).status,400);
const photos=['/assets/active-work.png','/assets/festive-work.png','/assets/sorvaq-work.png'];
for(const section of ['work','clients']){const gallery=await (await api(req('/save',{body:{...data,section,images:photos}}))).json();assert.deepEqual(Array.from(gallery.images),photos);assert.equal(gallery.media,photos[0]);const reordered=await (await api(req('/save',{body:{...gallery,images:[photos[2],photos[0]]}}))).json();assert.equal(reordered.media,photos[2]);const persisted=(await (await api(req('/entries'))).json()).find(x=>x.id===gallery.id);assert.deepEqual(Array.from(persisted.images),[photos[2],photos[0]]);}
assert.equal((await api(req('/save',{body:{...data,images:['javascript:bad']}}))).status,400);
assert.equal((await api(req('/save',{body:{...data,images:Array(21).fill(photos[0])}}))).status,400);
assert.equal((await api(req('/save',{body:{...data,images:[]}}))).status,400);
for(const item of [edit,{id:'work-cafe',revision:'seed'}]){
 const payload={id:item.id,revision:item.revision};
 for(const as of [null,'visitor'])assert.equal((await api(req('/delete',{as,body:payload}))).status,403);
 assert.equal((await api(req('/delete',{origin:'https://evil.test',body:payload}))).status,403);
 const removed=await (await api(req('/delete',{body:payload}))).json();assert.equal(removed.deleted,true);
 assert(!(await (await api(req('/entries',{as:null}))).json()).some(x=>x.id===item.id));
 assert.equal((await api(req('/delete',{body:payload}))).status,409);
 assert.equal((await api(req('/save',{body:removed}))).status,409);
 assert.equal((await api(req('/restore',{as:'visitor',body:{id:removed.id,revision:removed.revision}}))).status,403);
 const restored=await (await api(req('/restore',{body:{id:removed.id,revision:removed.revision}}))).json();assert.equal(restored.deleted,false);
 assert((await (await api(req('/entries'))).json()).some(x=>x.id===item.id));
}
console.log('PASS: deletion and undo for original and new projects, public exclusion, owner authorization and stale-edit protection.');
console.log('PASS: multi-image round trip, cover order, removal and gallery validation.');
console.log('PASS: owner/visitor authorization, CSRF, safe media, new records, existing edits, persistence and stale-edit protection.');})();
