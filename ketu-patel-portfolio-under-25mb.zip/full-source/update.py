from pathlib import Path
import runpy,shutil
root=Path('/workspace/sites/ketu-personal-portfolio');p=root/'dist'
scope=runpy.run_path(str(root/'build.py'));head=scope['head'];foot=scope['foot']
assets=p/'assets';assets.mkdir(exist_ok=True)
src=Path('/workspace/scratch/bd53882f98ef/client-assets')
for a,b in [('Active Carcare Brake Service Poster.png','active-work.png'),('Glossy Active Car Care Shield Logo(7).png','active-logo.png'),('SORVAQ_portrait_1080x1350.png','sorvaq-work.png'),('Diwali Sweets Gift Box Flat Lay.png','festive-work.png')]:shutil.copyfile(src/a,assets/b)
gmail='https://mail.google.com/mail/?view=cm&amp;fs=1&amp;to=ketuunjiya%40gmail.com'
wa='https://wa.me/917778004027?text=Hi%20Ketu%2C%20I%27d%20like%20to%20discuss%20a%20project%20and%20book%20a%20call.'
call='<dialog id="call-dialog"><button class="close" aria-label="Close call details">✕</button><p class="eyebrow">LET’S TALK</p><h2>Book a call</h2><p>Call me directly or DM me on WhatsApp to arrange a time.</p><a class="phone-number" href="tel:+917778004027">+91 7778004027</a><div class="call-actions"><a class="button" href="'+wa+'" target="_blank" rel="noopener">DM on WhatsApp ↗</a><a class="button secondary" href="tel:+917778004027">Call now</a></div></dialog>'
icons={
'work':'<div class="sculpture folder-icon"><div class="folder-sheet"></div><div class="folder-front"><span>✳</span></div></div>',
'expertise':'<div class="sculpture tools-icon"><div class="tool-card">Aa<span>DESIGN</span></div><div class="pen-tool"></div><div class="color-orb"></div></div>',
'about':'<div class="sculpture person-icon"><div class="person-head"></div><div class="person-body"></div><span class="person-badge">kp.</span></div>',
'clients':'<div class="sculpture clients-icon"><div class="client-slab slab-back">✳</div><div class="client-slab slab-front"><span>↗</span><b>BRANDS</b><i>Good work.<br>Good people.</i></div></div>'}
floating='<div class="floating-designs" aria-hidden="true"><div class="floater float-a"><span class="float-logo">kp.</span><small>IDENTITY STUDY</small></div><div class="floater float-b"><div class="mini-ui"><i></i><b></b><span></span><span></span></div><small>INTERFACE / 01</small></div><div class="floater float-c"><b>Less.<br>But better.</b><span>✳</span><small>POSTER EXPLORATION</small></div><div class="floater float-d"><span class="vector-path">⌁</span><small>MAKE EVERY POINT COUNT</small></div></div>'
projects=[('active-car-care','Active Car Care','Automotive · Social media design','active-work.png','<img src="/assets/active-logo.png" alt="Active Car Care logo">','Brake service campaign','A service-led social media design for Active Car Care, bringing the brake-care offering into a clear visual hierarchy.','The composition combines automotive photography, blue highlights and a bold headline. A focused service list helps the viewer scan the offering, while the contact details provide a clear next step.','Social media creative'),('sorvaq','SORVAQ','Fashion · Identity concept','sorvaq-work.png','<span class="brand-wordmark">SORVAQ</span>','An understated clothing identity','A clothing-brand concept exploring how a small wordmark can create presence without overpowering the garment.','A neutral palette, understated chest placement and a relaxed editorial image keep attention on the clothing. This is a personal brand exploration, rather than a claim of commissioned client work.','Brand application · Concept'),('festive-packaging','Festive Packaging','Packaging · Visual exploration','festive-work.png','<span class="brand-wordmark festive-mark">Thoughtfully<br>Gifted.</span>','A celebration in every detail','A festive packaging exploration built around illustrated architecture, florals and the warmth of Indian celebrations.','The box is presented as the centre of a gifting experience, surrounded by sweets and nuts. Warm ivory and rich ornamental detail create a balance between elegance and celebration. This is a design exploration.','Packaging presentation · Concept')]
cards=''
for slug,name,category,img,logo,title,intro,desc,kind in projects:
 cards+='<a class="client-project" href="/projects/'+slug+'.html"><div class="client-brand">'+logo+'<span>↗</span></div><div class="client-work-image"><img loading="lazy" src="/assets/'+img+'" alt="'+name+' project artwork"></div><div class="project-title"><h2>'+name+'</h2><span>↗</span></div><p>'+category+'</p></a>'
 d=p/'projects';d.mkdir(exist_ok=True)
 (d/(slug+'.html')).write_text(head(name)+'<main class="inner case-study"><a class="back" href="/clients.html">← All clients & projects</a><div class="page-intro"><p class="eyebrow">'+kind.upper()+'</p><div class="case-logo">'+logo+'</div><h1>'+title+'</h1><p>'+intro+'</p></div><img class="case-image" src="/assets/'+img+'" alt="'+name+' full project artwork"><section class="case-description"><p class="eyebrow">ABOUT THE PROJECT</p><h2>'+name+'</h2><p>'+desc+'</p><a class="button" href="'+gmail+'" target="_blank" rel="noopener">Discuss a similar project ↗</a></section><a class="back" href="/clients.html">← Back to clients</a></main>'+foot())
(p/'clients.html').write_text(head('Clients')+'<main class="inner"><a class="back" href="/">← Back home</a><div class="page-intro"><p class="eyebrow">04 / CLIENTS & BRAND EXPLORATIONS</p><h1>Good people.<br><span>Thoughtful work.</span></h1><p>A closer look at the brands and projects behind the visuals.<br>Client work and clearly labelled personal concepts.</p></div><div class="client-grid">'+cards+'</div></main>'+foot())

import re
for f in p.rglob('*.html'):
 s=f.read_text()
 s=s.replace('href="/contact.html">Contact</a>','href="/clients.html">Clients</a>').replace('href="/expertise.html">Expertise</a>','href="/expertise.html">Service</a>')
 s=s.replace('href="/contact.html">Say hello ↗</a>','href="'+gmail+'" target="_blank" rel="noopener">Email ↗</a>')
 if f.name=='index.html':
  s=s.replace('<main class="home">','<main class="home">'+floating)
  start=s.index('<div class="tiles">');end=s.index('<div class="home-bottom">',start)
  tiles='<div class="tiles">'
  for key,label in [('work','Work'),('expertise','Service'),('about','About'),('clients','Clients')]:
   tiles+='<a class="tile" href="/'+key+'.html"><div class="illustration '+key+'" aria-hidden="true">'+icons[key]+'</div><span>'+label+' <i>↗</i></span></a>'
  s=s[:start]+tiles+'</div>'+s[end:]
  s=s.replace('<a class="button" href="/work.html">Explore my work <span>↗</span></a>','<a class="button" href="'+gmail+'" target="_blank" rel="noopener">Email</a>')
  s=s.replace('<a class="button secondary" href="/contact.html">Let’s talk</a>','<button class="button secondary" type="button" data-call>Book a call</button>')
 if f.name=='contact.html':
  s=s.replace('<h2>Let’s make it happen.</h2>','<h2>Let’s make it happen.</h2><p><a href="'+gmail+'" target="_blank" rel="noopener">ketuunjiya@gmail.com ↗</a></p><p><a href="tel:+917778004027">+91 7778004027</a></p><button class="button" data-call>Book a call</button>')
 s=s.replace('<script src="/app.js"></script>',call+'<script src="/app.js"></script>')
 f.write_text(s)
